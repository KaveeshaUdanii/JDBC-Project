package thogakade;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ThogaKade {

    public static void main(String[] args) {
        String SQL = "Select * From Customer"; //Step 1 
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //Step II
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ThogaKade", "root", "mysql"); //Step III
            Statement stm = connection.createStatement(); //Step IV
            ResultSet rst = stm.executeQuery(SQL); //Step V
            while (rst.next()) { 
                String id = rst.getString("id");
                String name = rst.getString(2); //column index number
                String address = rst.getString(3);
                double salary = rst.getDouble("salary");
                System.out.println(id + "\t" + name + "\t" + address + "\t" + salary);
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver not found");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
}
